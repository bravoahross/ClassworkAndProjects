/*
 * CarScanner.h
 *
 *  Created on: Dec 6, 2022
 *      Author: jdicklin
 */

#include <stdint.h>
#include <inc/tm4c123gh6pm.h>
#include <stdbool.h>
#include "driverlib/interrupt.h"

int Scan_Objects(void);
