TESTING

We have more detailed independent tests for each component in their respective folders, but the tb_ALU file tests all of them in some capacity for a good overall check. 
