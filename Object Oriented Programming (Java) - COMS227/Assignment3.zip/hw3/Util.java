package hw3;

import java.io.File;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import api.GridCell;
import api.Line;
import api.Location;
import api.StringUtil;

/**
 * Utility class with methods to help initializing a Lines game from 
 * a string descriptor, and for creating a collection of games from
 * a file containing descriptors.
 */

public class Util {

  
  /**
   * Given a 2d array of GridCell, constructs an array of Line
   * objects based on the information in the grid.  Specifically,
   * for each pair of endpoints with matching ids, a corresponding
   * Line object is constructed with that id and with the given endpoints.
   * The order of the endpoints (endpoint 0 vs endpoint 1) is unspecified.
   * If there are more than two endpoints with the same id, or if there
   * is only one endpoint with the given id, this
   * method returns null. No other error-checking is performed (e.g. there
   * may be middle cells with no matching endpoint, or the game
   * may be unsolvable for other reasons).
   * <p>
   * Note that in general the id for a Line will <em>not</em> be the
   * same as its index in the returned array.
   * @param grid
   *   a 2d array of GridCell
   * @return
   *   array of Line objects based on the grid information
   */
  public static ArrayList<Line> createLinesFromGrid(GridCell[][] grid){
	ArrayList<Line> Lines = new ArrayList<Line>();
    int bad = 0;
    // Creates an array of ints to store endpoints
	int[] colors = new int[20];
    for( int row = 0; row < grid.length; row++){
    	for ( int column = 0; column < grid[row].length; column++) {
    		//If the location is an endpoint
    		if (grid[row][column].isEndpoint()) {
    			//Stores ID of the endpoint
    			int id1 = grid[row][column].getId();
    			for( int row2 = 0; row2 < grid.length; row2++){
    		    	for ( int column2 = 0; column2 < grid[row2].length; column2++) {
    		    		if (grid[row2][column2].isEndpoint()) {
    		    			//Stores ID of the next endpoint
    		    			int id2 = grid[row2][column2].getId();
    		    			//If the 2 endpoints IDs are the same and the locations are not the same
    		    			if ((id1 == id2) && ((row != row2) || (column != column2))) {
    		    				//Writes to the array of ints I made to store endpoints
    		    				colors[id1] = colors[id1] + 1;
    		    				//If this is the first time the endpoint has been found it adds the line to the ARRAY LIST
    		    				if(colors[id1] == 1) {
    		    				Location loc1 = new Location(row, column);
    		    				Location loc2 = new Location(row2, column2);
    		    				Line temp = new Line(id1, loc1, loc2);
    		    				Lines.add(temp);
    		    				}
    		    			}
    		    		}
    		    	}
    		    }
    			if (colors[id1] == 0) {
    				bad = 1;
    			}
    		}
    	}
    }
    //Checks if each endpoint is counted twice (once for each order)
	for(int t = 0; t < 20; t++) {
		if((colors[t] == 2) || (colors[t] == 0)) {
		}
		else {
			bad = 1;
		}
	}
	//If my flag has been triggered, the ArrayList is null
	if (bad == 1) {
		return null;
	}
	//If all constraints are satisfied, return array list lines
	return Lines;
  }
  
  /**
   * Reads the given file and constructs a list of LinesGame objects, one for
   * each descriptor in the file.  Descriptors in the file are separated by one or more
   * blank lines, where a "blank line" consists of some amount of whitespace and a 
   * newline character. The file may have extra whitespace at the beginning, 
   * and it must always end with one or more blank lines. Invalid descriptors
   * are ignored, so the method may return an empty list.  (A descriptor is "invalid"
   * if either createGridFromStringArray returns null, or createLinesFromGrid
   * returns null.)
   * @param filename
   *   name of the file to read
   * @return
   *   list of LinesGame objects created from the valid descriptors in the file
   * @throws FileNotFoundException
   *   if a file with the given name can't be opened
   */ 
  public static ArrayList<LinesGame> readFile(String filename) throws FileNotFoundException
  {
	  ArrayList<LinesGame> finish = new ArrayList<LinesGame>();
	  File text = new File(filename);
	  Scanner in = new Scanner(text);
	  ArrayList<String> descript = new ArrayList<String>();
	  boolean isDesc = false;
	 
	  //While there is a line in the text file
	  while (in.hasNextLine()){
		  String temp;
		  //Store the next line 
		  temp = in.nextLine();
		  // Empty line and should not be counted
		  if(temp.trim().isEmpty()) {
			  if(isDesc){
				  // Converts ArrayList to a string array
				  String[] descriptor = descript.toArray(new String[0]);	
				  // Creates GridCell from descript
				  GridCell[][] grid = StringUtil.createGridFromStringArray(descriptor);   
				  if (grid != null) {
					  ArrayList<Line> lines = createLinesFromGrid(grid);
					  if (lines != null) {
						  // Adds finished descriptor to ArrayList
						  LinesGame game = new LinesGame(grid, lines);
						  finish.add(game);
					  }
				  }
			  }
			  //Toggles isDesc to false because a space was detected which signifies the end of a descriptor
			  isDesc = false;
			  descript.clear();
		  }
		  else {							
			  // Not empty and should be added to array
			  descript.add(temp);
			  /*If the last line was not a descriptor, this will toggle isDesc to true because it is the start
			  of a new descriptor 
			  */
			  if(!isDesc) {
				  isDesc = true;
			  }
		  }
	  }
	  //Repeat of descriptor writing outside of while loop to catch the last descriptor read
	  if(isDesc){
		  String[] descriptor = descript.toArray(new String[0]);
		  GridCell[][] grid = StringUtil.createGridFromStringArray(descriptor);
		  if (grid != null) {
			  ArrayList<Line> lines = createLinesFromGrid(grid);
			  	if (lines != null) {
			  		LinesGame game = new LinesGame(grid, lines);
			  		finish.add(game);
			  	}
		  }
	  }
      return finish;
  }
  

  
  /**
   * Determines whether a line between two diagonally adjacent locations
   * would cross any existing line in the given list.
   * The check is based on the following test:
   * <ul>
   *  <li>Let (rOld, cOld) denote the current cell location and let (rNew, cNew) denote
   * the new cell location.  
   *  <li>Let rDiff = rNew - rOld and cDiff = cNew - cOld.
   *  <li>If either rDiff or cDiff does not have absolute value 1, then
   *  the two positions are not diagonally adjacent and the method returns false
   *  <li>If the two positions are diagonally adjacent, then p0 = (rOld, cOld + cDiff) 
   *  and p1 = (rOld + rDiff, cOld) always form the opposite diagonal (i.e., the 
   *  line that could potentially be crossed).
   *  <li>The method returns true if p0 and p1 occur consecutively, in either order,
   *  in any existing line in the given array.
   * </ul>
   * 
   * @param lines
   *   list of Line objects
   * @param currentLoc
   *   any Location
   * @param newLoc
   *   any Location
   * @return
   *   true if the two locations are diagonally adjacent and some
   *   existing line crosses the opposite diagonal
   */
  public static boolean checkForPotentialCrossing(ArrayList<Line> lines, Location currentLoc, Location newLoc){
	  int rOld = currentLoc.row();
	  int rNew = newLoc.row();
	  int cOld = currentLoc.col();
	  int cNew = newLoc.col();
	  int rDiff = rNew - rOld;
	  int cDiff = cNew - cOld;
	  boolean consec;
	  
	  //If the different between the new colums and rows is not 1 then return false
	  if ((Math.abs(rDiff) != 1) || (Math.abs(cDiff) != 1)){
		  return false;
	  }
	  //Create 2 locations to compare using checkForLineSegment
	  Location p0 = new Location (rOld, cOld + cDiff);
	  Location p1 = new Location (rOld + rDiff, cOld);
	  
	  consec = checkForLineSegment(lines, p0, p1);
	  
	  return consec;
  }
  
  /**
   * Determines whether any line in the given array already contains the segment between 
   * the given locations; that is, whether the two given locations occur consecutively,
   * in either order, in any of the given lines.
   * @param lines 
   *   any array of lines
   * @param currentLoc
   *   any position object
   * @param newLoc
   *   any position object
   * @return
   *   true if the two locations occur consecutively in some line
   */
  public static boolean checkForLineSegment(ArrayList<Line> lines, Location currentLoc, Location newLoc) {
    for (int i = 0; i < lines.size(); i++) {
    	ArrayList<Location> locations = lines.get(i).getCells();
    	int Current = locations.indexOf(currentLoc);
    	int New = locations.indexOf(newLoc);
    	//makes sure the selections are valid
    	if(Current >= 0 && New >= 0) {			
    		//tests if the values are next to each other
    		if (New == Current + 1 || New == Current - 1) {	
    			return true;
    		}
    	}
    }
    return false;
  }
  
}
