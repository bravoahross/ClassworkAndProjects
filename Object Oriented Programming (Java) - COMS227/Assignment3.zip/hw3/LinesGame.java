package hw3;

import java.util.ArrayList;


import api.GridCell;
import api.Line;
import api.Location;
import api.StringUtil;

/**
 * Game state for a Lines game.
 * @author ncros
 */
public class LinesGame
{
  
	
	private GridCell grid[][];
	private ArrayList<Line> lines;
	private String[] game;
	private Line currentLine;
	private int moves = 0;
    private Location lastCellPosition;
	
	  /**
	   * Constructs a LinesGame from the given grid and Line list.
	   * This constructor does not do any error-checking to ensure
	   * that the grid and the Line array are consistent. Initially
	   * the current line is null.
	   * @param givenGrid
	   *   a 2d array of GridCell
	   * @param givenLines
	   *   list of Line objects
	   */
		
	
    public LinesGame(GridCell[][] givenGrid, ArrayList<Line> givenLines)
  {
    grid = givenGrid;
    lines = givenLines;
  }
  
  /**
   * Constructs a LinesGame from the given descriptor. Initially the
   * current line is null.
   * @param descriptor
   *   array of strings representing initial state
   */
  public LinesGame(String[] descriptor)
  {
    game = descriptor;
  }
  
  /**
   * Returns the number of columns for this game.
   * @return
   *  width for this game
   */ 
  public int getWidth()
  {
    int columns;
    columns = grid[0].length;
    return columns;
  }
  
  /**
   * Returns the number of rows for this game.
   * @return
   *   height for this game
   */ 
  public int getHeight()
  {
	int rows;
	rows = grid.length;
	return rows;
  }
  
  /**
   * Returns the current cell for this game, possibly null.
   * The current cell is just the last location, if any, 
   * in the current line, if there is one. Returns null
   * if the current line is null or if the current line
   * has an empty list of locations.
   * @return
   *   current cell for this game, or null
   *   
   */
  public Location getCurrentLocation()
  {
    if(currentLine == null) 
    {
    	return null;
    }
    return currentLine.getLast();
  }
  
  /**
   * Returns the id for the current line, or -1
   * if the current line is null.
   * @return
   *   id for the current line
   */
  public int getCurrentId()
  {
    if(currentLine == null)
    {
    	return -1;
    }
    return currentLine.getId();
  }
  
  /**
   * Return this game's current line (which may be null).
   * @return
   *   current line for this game
   */
  public Line getCurrentLine()
  {
    return currentLine;
  }
  
  /**
   * Returns a reference to this game's grid.  Clients should
   * not modify the array.
   * @return
   *   the game grid
   */
  public GridCell[][] getGrid()
  {
    return grid;
  }
  
  /**
   * Returns the grid cell at the given position.
   * @param row
   *   given row
   * @param col
   *   given column
   * @return
   *   grid cell at (row, col)
   */
  public GridCell getCell(int row, int col)
  {
    return grid[row][col];
  }
  
  /**
   * Returns all Lines for this game.  Clients should not modify
   * the returned list or the Line objects.
   * @return
   *   list of lines for this game
   */ 
  public ArrayList<Line> getAllLines()
  {
    return lines;
  }
  
  /**
   * Returns the total number of moves.  A "move" means that a 
   * new Location was successfully added to the current line
   * in addCell.
   * @return
   *   total number of moves so far in this game
   */
  public int getMoveCount()
  {
    return moves;
  }
  
  /**
   * Returns true if all lines are connected and all
   * cells are at their maximum count.
   * @return
   *   true if all lines are complete and all cells are at max
   */ 
  public boolean isComplete() {
    for (GridCell[] r : grid) {		
    	for (GridCell c : r) {
    		if (!c.maxedOut()) return false;	//if all cells NOT at max
    	}
    }
    for (Line l : lines) {
    	if (!l.isConnected()) return false;		//if all lines NOT complete
    }
    return true;
  }
  
  /**
   * Attempts to set the current line based on the given
   * row and column.  When using a GUI, this method is typically 
   * invoked when the mouse is pressed. If the current line is 
   * already non-null, this method does nothing.		
   * There are two possibilities:
   * <ul>
   *   <li>Any endpoint can be selected.  Selecting an 						CASE 1
   *   endpoint clears the line associated with that endpoint's id,
   *   and all cells that were previously included in the line are decremented.
   *   The line then becomes the current line, and the endpoint is incremented
   *   and placed on the line's list of locations as its only element.
   *   <li>A non-endpoint cell can be selected if it is not a crossing		CASE 2
   *   and if it is the last cell in some line.  That line then becomes
   *   the current line.
   * </ul>
   * If neither of the above conditions is met, or if the
   * current line is non-null, this method does nothing.
   * 
   * @param row
   *   given row
   * @param col
   *   given column
   */
  public void startLine(int row, int col) {
	  // If selected line is null
	  if (currentLine == null) {
		  // If selected cell is an ENDPOINT   (CASE 1)
		  if (grid[row][col].isEndpoint()) {
			  // Gets ID from current location
			  int tempID = grid[row][col].getId();
			  for (int i = 0; i < lines.size(); i++) {
				  // If the IDs are the same 
				  if (tempID == lines.get(i).getId()) {
					  Line newL = lines.get(i);
					  ArrayList<Location> loc = newL.getCells();
					  for(int t = 0; t < loc.size(); t++) {
						  // Creates gridCell from location
						  Location currentLocation = loc.get(t);
						  GridCell currentCell = grid[currentLocation.row()][currentLocation.col()];
						  //Decrements cells of same ID type so they are not "filled"
						  currentCell.decrement();			
					  }
					  //Clears lines corresponding to endpoint ID
                      newL.clear();	
                      //Increments or "fills" selected endpoint
                      grid[row][col].increment();
                      currentLine = lines.get(i);
                      currentLine.add(new Location(row,col));
				  }
			    }
		  }
		  //If NOT endpoint (CASE 2)
		  else if(!grid[row][col].isEndpoint()) {				
			  if(!grid[row][col].isCrossing()) {
				  for (int y = 0; y < lines.size(); y++) {
					  Line tempLine = lines.get(y);
					  //Gets last filled line
					  Location end = tempLine.getLast(); 
					  if (end == null) return;
					  //If the selected point is the end of the line, you can add cells
					  if (end.col() == col && end.row() == row) {	
						  //If the line is "filled" then the current line is the temp Line
						  if (grid[row][col].getCount() == 1) {
							  currentLine = tempLine;
						  }
					  }
				  }
			  }
		  }
	  }
  }
  
  /**
   * Sets the current line to null. When using a GUI, this method is 
   * typically invoked when the mouse is released.
   */
  public void endLine()
  {
    currentLine = null;
  }
  
  /**
   * Attempts to add a new cell to the current line.  
   * When using a GUI, this method is typically invoked when the mouse is 
   * dragged.  In order to add a cell, the following conditions must be satisfied.
   * Here the "current cell" is the last cell in the current line, and "new cell"
   * is the cell at the given row and column:
   * :
   * <ol>
   *   <li>The current line is non-null
   *   <li>The current line is not connected
   *   <li>The given row and column are adjacent to the location of the current cell
   *       (horizontally, vertically, or diagonally) and not the same as the current cell
   *   <li>The count for the new cell is less than its max count
   *   <li>If the new cell is a MIDDLE or ENDPOINT, then its id matches
   *   the id for the current line
   *   <li>Adding the new cell will not cause the line to re-trace any
   *   existing line (according to the result of Util.checkForLineSegment)
   *   <li>Adding the new cell to the line would not cross any existing line
   *   (according to the result of Util.checkForPotentialCrossing)
   * </ol>
   * If the above conditions are met, a new Location at (row, col) is added
   * to the current line and the cell count is incremented.  Otherwise, the 
   * method does nothing.  If a new location
   * is added to the current line, the move counter is increased by 1.
   * @param row
   *   given row for the new cell
   * @param col
   *   given column for the new cell
   */
  public void addCell(int row, int col){
	// Checks if current line is non-null
    if (currentLine != null 
    		// The current line is not connected
    		&& !currentLine.isConnected()
    		// Checks if the current location is adjacent
    		&& isAdjacent(currentLine.getLast(), new Location(row, col))	//This if statement is so awful I made a helper method "isAdjacent" in an attempt to shorten it
    		// Checks if the cell count is less than its max count
    		&& !grid[row][col].maxedOut()) {
    		// Checks if the new cell is a MIDDLE or ENDPOINT, then its id matches the id for the current line
    	if (grid[row][col].isEndpoint() || (!grid[row][col].isCrossing() && !grid[row][col].isOpen())) {
    		if (!grid[row][col].idMatches(currentLine.getId())) return;
    	}
    	// Checks if the line is re-tracing
		if (!Util.checkForLineSegment(lines, new Location(row, col), currentLine.getLast())) {
			// Adds a new location to the current line and increments cell count and move count
			if (!Util.checkForPotentialCrossing(lines, new Location(row, col), currentLine.getLast())) {
				currentLine.add(new Location(row, col));
				grid[row][col].increment();
				moves += 1;
                lastCellPosition = new Location(row, col);
			}
		}
    }
  }
  
  /**
   * This is a helper I made to determine if cells are adjacent. 
   * It is similar to checkForLineSegment from util java, 
   * but does not read from an arrayList. It works by comparing the coords
   * from two locations I feed it and if they are greater than 1 away on either axis
   * the method returns false. Otherwise it returns true
   * @param line
   * 	First location to compare
   * @param line2
   * 	Second location to compare
   * @return
   * 	Returns true if the difference in rows or columns is greater than 1
   */
  private boolean isAdjacent(Location line, Location line2) {
	  if (line.equals(line2)) return false;
	  int x = line.col() - line2.col();
	  int y = line.row() - line2.row();
	  return Math.abs(x) < 2 && Math.abs(y) < 2;
  }

  /**
   * Returns a string representation of this game.
   */
  public String toString()
  {
    String result = "";
    result += "-----\n";
    result += StringUtil.originalGridToString(getGrid());
    result += "-----\n";
    result += StringUtil.currentGridToString(getGrid(), getAllLines());
    result += "-----\n";
    result += StringUtil.allLinesToString(getAllLines());
    Line ln = getCurrentLine();
    if (ln != null)
    {
      result += "Current line: " + ln.getId() + "\n";
    }
    else
    {
      result += "Current line: null\n";
    }
    return result;
  }

}
