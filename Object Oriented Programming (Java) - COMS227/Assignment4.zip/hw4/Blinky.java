package hw4;

import java.util.ArrayList;
import java.util.Random;

import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

public class Blinky extends Ghost{

	public Blinky(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location scatterTarget, Random rand) {
		super(maze, home, baseSpeed, homeDirection, scatterTarget, rand);
	}

	@Override
	protected Location getChaseTarget(Descriptor d) 
	{
		//Target in chase mode is always the player's location
		return d.getPlayerLocation();
	}
}
