package hw4;

import java.util.ArrayList;
import java.util.Random;

import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

public class Pinky extends Ghost
{
    public Pinky(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location scatterTarget, Random rand) 
    {
        super(maze, home, baseSpeed, homeDirection, scatterTarget, rand);
    }
    @Override
    protected Location getChaseTarget(Descriptor d) 
    {
        Location playerLoc = d.getPlayerLocation();
        //Sets Pinky's target to 4 ahead of the players location in the player's direction
        switch(d.getPlayerDirection()) 
        {
            case UP:
                return new Location(playerLoc.row() - 4, playerLoc.col());
            case DOWN:
                return new Location(playerLoc.row() + 4, playerLoc.col());
            case LEFT:
                return new Location(playerLoc.row(), playerLoc.col() - 4);
            case RIGHT:
                return new Location(playerLoc.row(), playerLoc.col() + 4);
            default:
                return null;
        }
    }
}