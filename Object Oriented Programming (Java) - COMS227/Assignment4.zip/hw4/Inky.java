package hw4;

import java.util.ArrayList;
import java.util.Random;

import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

public class Inky extends Ghost{

    public Inky(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location scatterTarget, Random rand) {
        super(maze, home, baseSpeed, homeDirection, scatterTarget, rand);
    }
    @Override
    protected Location getChaseTarget(Descriptor d) 
    {
        Location playerLoc = d.getPlayerLocation();
        Location pacManTargetLoc = null;
        //Gets location 2 spots ahead of player's location
        switch(d.getPlayerDirection()) 
        {
            case UP:
                pacManTargetLoc = new Location(playerLoc.row() - 2, playerLoc.col());
                break;
            case DOWN:
                pacManTargetLoc = new Location(playerLoc.row() + 2, playerLoc.col());
                break;
            case LEFT:
                pacManTargetLoc = new Location(playerLoc.row(), playerLoc.col() - 2);
                break;
            case RIGHT:
                pacManTargetLoc = new Location(playerLoc.row(), playerLoc.col() + 2);
                break;
            default:
                return null;
        }
        Location blinkyLoc = d.getBlinkyLocation();
        int xDiff = blinkyLoc.row() - pacManTargetLoc.row();
        int yDiff = blinkyLoc.col() - pacManTargetLoc.col();
        //Sets target to 2x the vector starting at blinkyLoc going to pacManTargetLoc
        return new Location(blinkyLoc.row() + xDiff * 2, blinkyLoc.col() + yDiff * 2);
    }
}
