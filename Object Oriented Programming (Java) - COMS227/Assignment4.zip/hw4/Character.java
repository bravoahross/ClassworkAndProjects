package hw4;

import api.Actor;
import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

/*
 * Abstract Superclass for holding common methods of the "Pacman" and "Ghost" objects
 */
public abstract class Character implements Actor 
{
	
	  /**
	   * Maze configuration.
	   */
	  private MazeMap maze;
	  
	  /**
	   * Initial location on reset().
	   */
	  private Location home;
	  
	  /**
	   * Initial direction on reset().
	   */
	  private Direction homeDirection;
	  
	  /**
	   * Current direction of travel.
	   */
	  private Direction currentDirection;
	  
	  /**
	   * Basic speed increment, used to determine currentIncrement.
	   */
	  private double baseIncrement;
	  
	  /**
	   * Current speed increment, added in direction of travel each frame.
	   */
	  private double currentIncrement;
	  
	  /**
	   * Row (y) coordinate, in units of cells.  The row number for the
	   * currently occupied cell is always the int portion of this value.
	   */
	  private double rowExact;
	  
	  /**
	   * Column (x) coordinate, in units of cells.  The column number for the
	   * currently occupied cell is always the int portion of this value.
	   */
	  private double colExact;
	  
	  /**
	   * Constructs a new Character with the given maze, home location, base speed,
	   * and initial direction.
	   * @param maze
	   *   maze configuration
	   * @param home
	   *   initial location
	   * @param baseSpeed
	   *   base speed increment
	   * @param homeDirection
	   *   initial direction
	   */
	  public Character(MazeMap maze, Location home, double baseSpeed, Direction homeDirection)
	  {
	    this.maze = maze;
	    this.home = home;
	    this.baseIncrement = baseSpeed;
	    this.currentIncrement = baseSpeed;
	    this.homeDirection = homeDirection;
	  }
	  /*
	   * Getter methods from PACMAN
	   */
	  public MazeMap getMaze()
	  {
		  return maze;
	  }
	  
	  @Override
	  public double getBaseIncrement()
	  {
	    return baseIncrement;
	  } 
	  
	  @Override
	  public double getColExact()
	  {
	    return colExact;
	  }
	   
	  @Override
	  public Direction getCurrentDirection()
	  {
	    return currentDirection;
	  }
	  
	  @Override
	  public double getCurrentIncrement()
	  {
	    return currentIncrement;
	  }
	  
	  /*
	   * Sets current Increment
	   */
	  protected void setCurrentIncrement(double increment) 
	  {
		  currentIncrement = increment; 
	  }
	  
	  @Override
	  public Location getCurrentLocation()
	  {
	    return new Location((int) rowExact, (int) colExact);
	  }
	  
	  @Override
	  public Direction getHomeDirection()
	  {
	    return homeDirection;
	  }
	  
	  @Override
	  public Location getHomeLocation()
	  {
	    return home;
	  }
	  
	  public abstract Mode getMode();
	  
	  @Override
	  public double getRowExact()
	  {
	    return rowExact;
	  }
	  
	  @Override
	  public void reset()
	  {
	    Location homeLoc = getHomeLocation();
	    setRowExact(homeLoc.row() + 0.5);
	    setColExact(homeLoc.col() + 0.5);
	    setDirection(getHomeDirection());
	    setCurrentIncrement(getBaseIncrement());
	  }

	  @Override
	  public void setColExact(double c)
	  {
	    colExact = c;
	  }

	  @Override
	  public void setDirection(Direction dir)
	  {
	    currentDirection = dir;
	  }
	  
	  @Override
	  public void setMode(Mode mode, Descriptor desc)
	  {
	    //does nothing
	  }
	  
	  @Override
	  public void setRowExact(double r)
	  {
	    rowExact = r;
	  }
}