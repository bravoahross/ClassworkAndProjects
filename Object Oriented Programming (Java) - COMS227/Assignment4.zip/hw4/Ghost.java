package hw4;

import java.util.ArrayList;
import java.util.Random;

import api.Descriptor;
import api.Direction;
import api.Location;
import api.MazeMap;
import api.Mode;

/*
 * Abstract superclass that holds common methods shared between ghosts, but not Pacman
 */
public abstract class Ghost extends Character{

	/*
	 * Variables to store data passed in the constructor
	 */
	private Location scatterTarget;
	private Random rand; 
	private Mode currentMode;
	private Location nextLoc;
	private Direction nextDir;
	
	/*
	 * Constructor for the Ghost
	 */
	public Ghost(MazeMap maze, Location home, double baseSpeed, Direction homeDirection, Location scatterTarget, Random rand) {
		super(maze, home, baseSpeed, homeDirection);
		this.rand = rand;
		this.scatterTarget = scatterTarget;
		currentMode = Mode.INACTIVE;
		setDirection(homeDirection);
	}
	
	/*
	 * Every ghost has it's own chase target, so this tells each ghost that extends Ghost to include a chaseTarget
	 */
	protected abstract Location getChaseTarget(Descriptor d);
	
	protected Random getRand() 
	{
		return rand;
	}

	protected Location getScatterTarget() 
	{
		return scatterTarget;
	}

	@Override
	public Mode getMode() {
		return currentMode;
	}

	protected Direction getNextDir() {
		return nextDir;
	}

	protected Location getNextLoc() {
		return nextLoc;
	}

	protected void setNextLoc(Location loc) {
		nextLoc = loc;
	}

	protected void setNextDir(Direction dir) {
		nextDir = dir;
	}

	/*
	 * Uses the pythagorean thm as a distance formula
	 */
	protected double getDistance(Location loc1, Location loc2) 
	{
		return Math.sqrt(Math.pow( loc1.row() - loc2.row(),2) + Math.pow( loc1.col() - loc2.col(),2));
	}
	
	/*
	 * Returns the location of adjacent cell to ghostLoc with the minimum distance to playerLoc
	 */
	protected Location getClosestLoc(Location ghostLoc, Location playerLoc) {
		double upDist, downDist, rightDist, leftDist;
		Location upLoc = new Location(ghostLoc.row() - 1, ghostLoc.col());
		Location downLoc = new Location(ghostLoc.row() + 1, ghostLoc.col());
		Location rightLoc = new Location(ghostLoc.row(), ghostLoc.col() + 1);
		Location leftLoc = new Location(ghostLoc.row(), ghostLoc.col() - 1);
		
		if (getMaze().isWall(ghostLoc.row() - 1, ghostLoc.col())) {		//If cell is a wall, set to MAX_VALUE
			upDist = Integer.MAX_VALUE;									
		} else {														//If isn't a wall, calculates actual distance
			upDist = getDistance(upLoc, playerLoc);						
		}
		if (getMaze().isWall(ghostLoc.row() + 1, ghostLoc.col())) {
			downDist = Integer.MAX_VALUE;
		} else {
			downDist = getDistance(downLoc, playerLoc);
		}
		if (getMaze().isWall(ghostLoc.row(), ghostLoc.col() - 1)) {
			leftDist = Integer.MAX_VALUE;
		} else {
			leftDist = getDistance(leftLoc, playerLoc);
		}
		if (getMaze().isWall(rightLoc.row(), ghostLoc.col()  + 1)) {
			rightDist = Integer.MAX_VALUE;
		} else {
			rightDist = getDistance(rightLoc, playerLoc);
		}
		if (getMode() != Mode.FRIGHTENED && getCurrentDirection() != null) //If not frightened, sets distance behind it to max because non-frightened ghosts can't turn around
		{
			switch(getCurrentDirection()) 
			{
				case UP:
					downDist = Integer.MAX_VALUE;
					break;
				case DOWN:
					upDist = Integer.MAX_VALUE;
					break;
				case LEFT:
					rightDist = Integer.MAX_VALUE;
					break;
				case RIGHT:
					leftDist = Integer.MAX_VALUE;
					break;
			}
		}
		
		/*
		 * Finds minimum distance 
		 */
		double min = Math.min(Math.min(upDist, downDist), Math.min(leftDist, rightDist));
		
		/*
		 * Sets direction to minimum distance and returns location of minimum cell path
		 */
		if (Math.abs(upDist - min) < Pacman.ERR) {
			if (getCurrentDirection() == null) setDirection(Direction.UP);
			return upLoc;
		} else if (Math.abs(leftDist - min) < Pacman.ERR) {
			if (getCurrentDirection() == null) setDirection(Direction.LEFT);
			return leftLoc;
		} else if (Math.abs(downDist - min) < Pacman.ERR) {
			if (getCurrentDirection() == null) setDirection(Direction.DOWN);
			return downLoc;
		} else {
			if (getCurrentDirection() == null) setDirection(Direction.RIGHT);
			return rightLoc;
		}
	}

	/*
	 * Helper method to get the direction needed to go between two given cells
	 */
	protected Direction getDirectionToAdj(Location start, Location end) {
		if (start.row() -1 == end.row()) {
			return Direction.UP;
		} else if (start.row() +1 == end.row()) {
			return Direction.DOWN;
		} else if (start.col() -1 == end.col()) {
			return Direction.LEFT;
		} else {
			return Direction.RIGHT;
		}
	}

	/*
	 * Sets mode, then sets the increment(speed) based on mode, then calculates the next cell
	 */
	@Override
	public void setMode(Mode newMode, Descriptor d) {
		currentMode = newMode;
		switch (currentMode) {
			case FRIGHTENED:
				setCurrentIncrement(getBaseIncrement() * (2.0/3));
				break;
			case DEAD:
				setCurrentIncrement(getBaseIncrement() * 2);
			default:
				setCurrentIncrement(getBaseIncrement());
		}
		calculateNextCell(d);

	}
	
	/*
	 * Gets distance to center, from Pacman
	 */
	protected double distanceToCenter()
	  {
	    double colPos = getColExact();
	    double rowPos = getRowExact();
	    switch (getCurrentDirection())
	    {
	      case LEFT:
	        return colPos - ((int) colPos) - 0.5;
	      case RIGHT:
	        return 0.5 - (colPos - ((int) colPos));
	      case UP:
	        return rowPos - ((int) rowPos) - 0.5;
	      case DOWN:
	        return 0.5 - (rowPos - ((int) rowPos));
	    }    
	    return 0;
	  }

	/*
	 * Moves 
	 */
	@Override
	public void update(Descriptor desc) 
	{
		double diff = Math.abs(distanceToCenter());
		double increment = getCurrentIncrement();
		Direction beforeDir = getCurrentDirection();
		int rowNum = (int) getRowExact();
		int colNum = (int) getColExact();
		
		//Changes direction if not currently moving that way
		if (diff < Pacman.ERR && nextDir != getCurrentDirection() && nextDir != null) 
		{
			setDirection(nextDir);
			return;
		}
		
		//When you reach the center of a cell, if currentDir is not nextDir, update direction
		if (increment > diff) 
		{
			move (diff);
			if (getCurrentDirection() != nextDir && nextDir != null) setDirection(nextDir);

			if (nextDir == beforeDir) 
			{
				move(increment - diff);
			}
		}
		
		else 
		{
			move(increment);
		}

		//If after it moves it is in a different cell, calculate next cell
		if (rowNum != (int) getRowExact() || colNum != (int) getColExact()) {
			calculateNextCell(desc);
		}

	}
	
	//Pacman movement code
	private void move(double increment) 
	{
		double curRowExact = getRowExact();
		double curColExact = getColExact();
		int rowNum = (int) curRowExact;
		int colNum = (int) curColExact;

		double diff = distanceToCenter();

		switch(getCurrentDirection()) 
		{
			case LEFT:
				// special case: check whether we are in the tunnel and need to wrap around
				if (curColExact - increment - 0.5 < 0)
				{
					curColExact = getMaze().getNumColumns() + (curColExact - increment - 0.5);
				}
				else
				{
					// if we are approaching a wall, be sure we stop moving
					// at the center of current cell.  This only applies when
					// 'diff' is positive but small enough that we can't move a full
					// increment
					if (diff > -Pacman.ERR && diff < increment && getMaze().isWall(rowNum, colNum - 1))
					{
						increment = diff;
					}
					curColExact -= increment;
				}
				break;
			case RIGHT:
				// special case: check whether we are in the tunnel and need to wrap around
				if (curColExact + increment + 0.5 >= getMaze().getNumColumns())
				{
					curColExact = curColExact + increment + 0.5 - getMaze().getNumColumns();
				}
				else
				{
					if (diff > -Pacman.ERR && diff < increment && getMaze().isWall(rowNum, colNum + 1))
					{
						increment = diff;
					}
					curColExact += increment;
				}
				break;
			case UP:
				if (diff > -Pacman.ERR && diff < increment && getMaze().isWall(rowNum - 1, colNum))
				{
					increment = diff;
				}
				curRowExact -= increment;
				break;
			case DOWN:
				if (diff > -Pacman.ERR && diff < increment && getMaze().isWall(rowNum + 1, colNum))
				{
					increment = diff;
				}
				curRowExact += increment;
				break;
		}
		setRowExact(curRowExact);
		setColExact(curColExact);
	}
	
	
	public Location getNextCell() 
	{
		return nextLoc;
	}

	
	public void calculateNextCell(Descriptor d) 
	{
		//If it passed the center of the cell and is going in the respective direction, it does nothing
		if (getCurrentDirection() == Direction.UP && (getRowExact() % 1) < .5 - Pacman.ERR ) return;
		if (getCurrentDirection() == Direction.DOWN && (getRowExact() % 1) > .5 + Pacman.ERR ) return;
		if (getCurrentDirection() == Direction.LEFT && (getColExact() % 1) < .5 - Pacman.ERR ) return;
		if (getCurrentDirection() == Direction.RIGHT && (getColExact() % 1) > .5 + Pacman.ERR ) return;
		Location targetLoc = null;
		
		//Gets target location based on current mode
		switch (getMode()) {
			case INACTIVE:
				setNextLoc(null);
				return;
			case CHASE:
				targetLoc = getChaseTarget(d);
				break;
			case FRIGHTENED:
				ArrayList<Location> possibleMoveLocs = new ArrayList<>();
				//Gets all adjacent locations 
				Location upLoc = new Location((int) getRowExact() - 1, (int) getColExact());
				Location downLoc = new Location((int) getRowExact() + 1, (int) getColExact());
				Location rightLoc = new Location((int) getRowExact(), (int) getColExact() + 1);
				Location leftLoc = new Location((int) getRowExact(), (int) getColExact() - 1);
				//If the next location in it's respective location isn't a wall and isn't behind the ghost it adds it to an ArrayList of possible moves
				if (!getMaze().isWall(upLoc.row(), upLoc.col()) && getCurrentDirection() != Direction.DOWN ) possibleMoveLocs.add(upLoc);
				if (!getMaze().isWall(downLoc.row(), downLoc.col()) && getCurrentDirection() != Direction.UP) possibleMoveLocs.add(downLoc);
				if (!getMaze().isWall(rightLoc.row(), rightLoc.col()) && getCurrentDirection() != Direction.LEFT) possibleMoveLocs.add(rightLoc);
				if (!getMaze().isWall(leftLoc.row(), leftLoc.col()) && getCurrentDirection() != Direction.RIGHT) possibleMoveLocs.add(leftLoc);
				//If there is a possible move, it takes a random move
				if (possibleMoveLocs.size() > 0) 
				{
					targetLoc = possibleMoveLocs.get(getRand().nextInt(possibleMoveLocs.size()));
				} 
				//If the ghost can only go backwards, it will move backwards
				else 
				{
					switch(getCurrentDirection()) {
						case UP:
							targetLoc = downLoc;
							break;
						case DOWN:
							targetLoc = upLoc;
							break;
						case LEFT:
							targetLoc = rightLoc;
							break;
						case RIGHT:
							targetLoc = leftLoc;
							break;
					}
				}
				break;
			case DEAD:
				targetLoc = getHomeLocation();
				break;
			case SCATTER:
				targetLoc = getScatterTarget();
				break;
		}
		//Set nextLoc to the cell with the lowest distance to target
		setNextLoc(getClosestLoc(getCurrentLocation(), targetLoc));
		//Set nextDir to the direction necessary to move from currentLoc to nextLoc
		setNextDir(getDirectionToAdj(getCurrentLocation(), getNextLoc()));

	}
}
