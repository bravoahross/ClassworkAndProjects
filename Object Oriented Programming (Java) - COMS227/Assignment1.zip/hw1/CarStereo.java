package hw1;
/**
 * Model of a car stereo 
 * @author ncros
 *
 */
public class CarStereo {
public static final double VOLUME_STEP = 0.16;		//Increment the volume can be moved up/down
private double Vol = 0.5;							//Starting volume
private double Freq;								//Initl. instance values
private double maxFreq;
private double minFreq;
private int stations;
private double lowestStation;
private int save;
private double interval;
/**
 * Constructor to read given Stereo values
 * @param givenMinFrequency
 * 	Minimum Frequency the stereo can listen to
 * @param givenMaxFrequency
 * 	Maximum Frequency the stereo can listen to 
 * @param givenNumStations
 * 	Number of stations included between the max and min frequency
 */
public CarStereo(double givenMinFrequency, double givenMaxFrequency,
int givenNumStations) 
{
	maxFreq = givenMaxFrequency;					// Reads given values of the Stereo
	minFreq = givenMinFrequency;
	stations = givenNumStations;
	Freq = minFreq;
	
}
/**
 * Returns current volume
 * @return
 */
public double getVolume() 
{
	return Vol;
}
/**
 * Raises the volume until its max of 1.0
 */
public void louder()
{
	double maxVol = 1.0;
	Vol += VOLUME_STEP;
	Vol = Math.min(Vol,maxVol);						// Keeps Vol under/= max
}
/**
 * Lowers the volume until its minimum of 0.0
 */
public void quieter()
{
	double minVol = 0.0;
	Vol -= VOLUME_STEP;
	Vol = Math.max(Vol,minVol);						// Keeps Vol above/= min
}
/**
 * Returns current Frequency
 * @return
 */
public double getTuner() 
{
	return Freq;
}
/**
 * Changes Freq to new input frequency
 * @param givenFrequency
 * 	The input frequency
 */
public void setTuner(double givenFrequency)
{
	Freq = givenFrequency; 
	Freq = Math.min(Freq,maxFreq);					// Keeps freq in acceptable range
	Freq = Math.max(Freq,minFreq);
}
/**
 * Changes Freq to new input assigned with a dial using degree conversion
 * @param degrees
 * 	The degrees the dial is turned
 */
public void turnDial(double degrees)
{
	
	Freq = Freq + (degrees / (360/(maxFreq-minFreq)));
	Freq = Math.min(Freq,maxFreq);					// Keeps freq in acceptable range
	Freq = Math.max(Freq,minFreq);
}
/**
 * Using a station number, assigns a frequency to Freq
 * @param stationNumber
 */
public void setTunerFromStationNumber(int stationNumber)
{
	interval = (maxFreq - minFreq) / stations;
	Freq = stationNumber * interval + interval / 2 + minFreq;	// Interpretations of the formula given to find stations
	lowestStation = interval / 2 + minFreq;
	double highestStation = (stations - 1) * interval + interval / 2 + minFreq;
	Freq = Math.min(Freq,highestStation);			// Keeps freq in acceptable range
	Freq = Math.max(Freq,lowestStation);
}
/**
 * Using Freq, identifies which station is on
 * @return
 * 	Returns the station #
 */
public int findStationNumber()
{
	int ans;
	interval = (maxFreq - minFreq) / stations;
	lowestStation = interval / 2 + minFreq;
	ans = (int) Math.round((Freq - lowestStation) / interval);
	ans = Math.min(ans, (stations - 1));							// Keep ans in range
	return ans;
}
/**
 * Finds current station, and then chooses the previous station with a wrap around feature
 */
public void seekDown()
{
	int dwnStation = findStationNumber();
	dwnStation = (dwnStation + stations - 1) % stations;			// Uses previous methods to find what station they are at, then decrease
	setTunerFromStationNumber(dwnStation);
}
/**
 * Finds current station, and then chooses the next station with a wrap around feature
 */
public void seekUp()
{
	int upStation = findStationNumber();
	upStation = (upStation + 1)% stations;
	setTunerFromStationNumber(upStation);							// Uses previous methods to find what station they are at, then increase
}
/**
 * Saves current station
 */
public void savePreset()
{
	save = findStationNumber();										// assign save variable with nearest station
}
/**
 *  Outputs saved station
 */
public void goToPreset()
{
	setTunerFromStationNumber(save);								// Go to saved station
}

}
