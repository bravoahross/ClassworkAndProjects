package hw2;
import api.ThrowType;
import static api.ThrowType.*;
/**
 * This class models a standard game of darts, keeping track of the scores,
 * whose turn it is, and how many darts the current player has remaining.
 * The number of starting points and the number of darts used in 
 * a player's turn are configurable.
 * @author ncros
 */
public class DartGame
{  
/**
 * initializes private shared variables
 */
	private int score1 = 0;
	private int score0 = 0;
	private int currentPlayer = 0;
	private int dartCount = 0;
	private int startScore = 0;
	private int initDartCount = 0;
	
/**
 * 
 * @param startingPlayer
 * gives the value for the starting player (0 or 1)
 * @param startingPoints
 * gives the value for the starting points (any integer)
 * @param numDarts
 * gives the value for darts per turn (any integer)
 */
  
	public DartGame(int startingPlayer, int startingPoints, int numDarts) 
	{
		currentPlayer = startingPlayer;
		score1 = startingPoints;
		score0 = startingPoints;
		initDartCount = numDarts;
		dartCount = initDartCount;
		startScore = startingPoints;
	}
/**
 * 
 * @param startingPlayer
 * gives the value for the starting player (0 or 1)
 */
	public DartGame(int startingPlayer)
	{
		currentPlayer = startingPlayer;
		score1 = 301;
		score0 = 301;
		dartCount = 3;
		initDartCount = 3;
	}
	
	
	
  /**
   * Returns the player whose turn it is.  (When the game is over,
   * this method always returns the winning player.)
   * @return
   *   current player (0 or 1)
   */
  public int getCurrentPlayer()
  {
	if (whoWon() == 1) 
	{
		currentPlayer = 1;
	}
	else if (whoWon() == 0) 
	{
		currentPlayer = 0;
	}
    return currentPlayer;
  }
  
  /**
   * Returns the score of the indicated player (0 or 1).  If
   * the argument is any value other than 0 or 1, the method returns
   * -1.
   * @param which
   *   indicator for which player (0 or 1)
   * @return
   *   score for the indicated player, or -1 if the argument is invalid
   */
  public int getScore(int which)
  {
	int score = 0;
    if (which == 0) 
    {
    	score = score0;
    }
    else if (which == 1) 
    {
    	score = score1;
    }
    else {
    	score = -1;
    }
    return score;
  }
  
  /**
   * Returns the number of darts left in the current player's turn.
   * @return
   *   the number of darts left in the current player's turn
   */
  public int getDartCount()
  {
    return dartCount;
  }
  
  /**
   * Returns the points given the type of score.
   * @return
   *   points given the type of score
   */
  public static int calcPoints(ThrowType type, int number)
  {
	  int points = 0;
	  if (type == ThrowType.SINGLE) 
	  {
		  points = number;
	  }
	  else if (type == ThrowType.DOUBLE) 
	  {
		  points = number * 2;
	  }
	  else if (type == ThrowType.TRIPLE) 
	  {
		  points = number * 3;
	  }
	  else if (type == ThrowType.OUTER_BULLSEYE) 
	  {
		  points = 25;
	  }
	  else if (type == ThrowType.INNER_BULLSEYE) 
	  {
		  points = 50;
	  }
	  return points;
  }
  /**
   * Reduces the score for the current player by the given amount.
   * @param amount
   * number of points to subtract
   */
  private void adjustScore(int amount) 
  {
	  if (currentPlayer == 1) 
	  {
		  score1 -= amount;
	  }
	  else if (currentPlayer == 0) 
	  {
		  score0 -= amount;
	  }
  }
  
  /**
   * Switches players and resets the dart count and
   * the starting score for the current player's turn.
   */
   private void switchPlayer() 
   {
	 if (isOver() == false) 
	 {
	   if (currentPlayer == 1) 
	   {
		   currentPlayer = 0;
		   startScore = score0;
	   }
	   else 
	   {
		   currentPlayer = 1;
		   startScore = score1;
	   }
	   dartCount = initDartCount;
	 }
   }
   /**
    * Returns who won the game after it is called
    * @return
    *   The player who won. 1 if player 1 wins, 0 if player 0 wins,  
    *   and -1 if no one has won 
    */
  public int whoWon() 
  {
	  int winner = -1;
	  if(score1 == 0) 
	  {
		  winner = 1;
	  }
	  else if(score0 == 0) 
	  {
		  winner = 0;
	  }
	  return winner;
  }
  /**
   * Returns the boolean expressing if the game is over 
   * @return
   *   returns true if the game is over, otherwise returns false
   */
  public boolean isOver () 
  {
	  boolean match = false;
	  if(score1 == 0) 
	  {
		  match = true;
	  }
	  else if(score0 == 0) 
	  {
		  match = true;
	  }
	  return match;
  }
  
  private boolean doubIN1 = false;
  private boolean doubIN0 = false;
  /**
   * Throws a dart
   * @param type
   * An enum representing the type of throw. Used to calculate points scored
   * @param number
   * A number that is used to calculate points scored
   */
  public void throwDart(ThrowType type, int number)
  {
	  if (isOver()== false) 
      {
		  boolean doubOUT = false;
		  boolean doubIN = false;
		  if ((type == DOUBLE) || (type == INNER_BULLSEYE)) 	//establishes conditions for doubling in and out 
		  {
			  doubOUT = true;
			  if (currentPlayer == 1) 
			  {
				  doubIN1 = true;
			  }
			  else if (currentPlayer == 0) 
			  {
				  doubIN0 = true;
			  }
		  }
		  if (currentPlayer == 1) 
		  {
			  doubIN = doubIN1;
		  }
		  if (currentPlayer == 0) 
		  {
			  doubIN = doubIN0;
		  }
	  		if (doubIN == true) 
	  		{
	  			int points = 0;
	  			dartCount -= 1;
	  			points = calcPoints(type, number);
	  		    adjustScore(points);
	  		    if (currentPlayer == 1) 
	  		    {
	  		      if ((score1 == 0) && (doubOUT == true))	//condition for player 1 win
	  		          {
		  				  isOver();
		  				  whoWon();
		  			  }
	  		      else if ((score1 <= 0) || (score1 == 1))	//condition for player 1 bust
	  		      {
	  				  score1 = startScore;
	  				  switchPlayer();
	  			  }
	  		    }
	  		    else if (currentPlayer == 0) 
	  		    {
	  		      if ((score0 == 0) && (doubOUT == true))	//condition for player 0 win
	  		          {
		  				  isOver();
		  				  whoWon();
		  			  }
	  		      else if ((score0 <= 0) || (score0 == 1))	//condition for player 0 bust
	  		      {
	  				  score0 = startScore;
	  				  switchPlayer();
	  			  }
	  		    }
			  if (dartCount == 0) 
			    {
			  		switchPlayer();
			  	}    
	  		}
	  		else if(doubIN == false) 			//If current player hasn't doubled in yet
	  		{
				  dartCount -= 1;
				  if (dartCount == 0) 
				    {
				  		switchPlayer();
				  	}
			}
      }
  }
  /**
   * Returns a string representation of the current game state.
   */
  public String toString()
  {
    String result = "Player 0: " + getScore(0) +
                    "  Player 1: " + getScore(1) +
                    "  Current: Player " + getCurrentPlayer() +
                    "  Darts: " + getDartCount();
    return result;
  }
}